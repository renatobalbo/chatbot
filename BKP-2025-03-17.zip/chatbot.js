require('dotenv').config();
const fs = require('fs');
const qrcode = require('qrcode-terminal');
const { Client } = require('whatsapp-web.js');

const { getConnection, sql } = require('./database');
const { registrarInteracao } = require('./interactionLog');
const { generateStatementReport } = require('./reports');
const { getCarteiras, saveCarteiraToDB, getCarteiraIdPorCodigo, consultarSaldo, exibirSaldo, listarCarteiras } = require('./wallets');
const { getCategorias, saveCategoriaToDB, checkCategoriaExists, checkCategoriaInUse, deleteCategoriaFromDB, listCategorias, listarCategorias } = require('./categories');
const { iniciarAssinatura, verificarAssinatura, cancelarAssinatura, PLANOS } = require('./subscription');
const simpleGit = require('simple-git');

const userManager = require('./userManagement');

const git = simpleGit({
  baseDir: process.cwd(),
  binary: 'git',
  maxConcurrentProcesses: 6,
  config: [
    `http.extraheader=AUTHORIZATION: token ${process.env.GITHUB_TOKEN}`
  ]
});

const client = new Client();

//Chamada do QRCode e conexão com o Whatsapp
client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('Tudo certo! WhatsApp conectado.');
});

// Estado do usuário
const userState = {};

// Função para salvar movimentações no banco.
const saveTransactionToDB = async (user, tipo, valor, carteiraCodigo, categoria) => {
    try {
        let pool = await getConnection();

        // Busca o ID da carteira com base no código informado
        const carteiraResult = await pool.request()
            .input('Usuario', sql.NVarChar, user)
            .input('Codigo', sql.Int, carteiraCodigo)
            .query("SELECT ID FROM Carteiras WHERE Codigo = @Codigo AND (Usuario = @Usuario OR Usuario = 'GERAL')");

        if (carteiraResult.recordset.length === 0) {
            const erro = `Carteira com código ${carteiraCodigo} não encontrada.`;
            
            // Log de erro na carteira
            await registrarInteracao(
                user,
                'ERRO_CARTEIRA',
                carteiraCodigo.toString(),
                erro,
                'consulta_carteira',
                'ERRO',
                { carteiraCodigo }
            );
            
            throw new Error(erro);
        }

        const carteiraID = carteiraResult.recordset[0].ID;

        await pool.request()
            .input('Usuario', sql.NVarChar, user)
            .input('Data', sql.DateTime, new Date())
            .input('Tipo', sql.NVarChar, tipo)
            .input('Valor', sql.Decimal(10,2), parseFloat(valor))
            .input('Carteira', sql.Int, carteiraID)
            .input('Categoria', sql.Int, categoria)
            .query("INSERT INTO Movimentacoes (Usuario, Data, Tipo, Valor, Carteira, Categoria) VALUES (@Usuario, @Data, @Tipo, @Valor, @Carteira, @Categoria)");
        
        // Log de sucesso na transação
        await registrarInteracao(
            user,
            'TRANSACAO',
            'saveTransactionToDB',
            `Transação ${tipo} salva com sucesso`,
            'banco_dados',
            'SUCESSO',
            {
                tipo,
                valor: parseFloat(valor),
                carteiraID,
                categoria
            }
        );
    } catch (err) {
        console.error('Erro ao salvar movimentação:', err.message);
        
        // Log de erro na transação
        await registrarInteracao(
            user,
            'TRANSACAO',
            'saveTransactionToDB',
            `Erro: ${err.message}`,
            'banco_dados',
            'ERRO',
            {
                tipo,
                valor,
                carteiraCodigo,
                categoria,
                erro: err.message
            }
        );
        
        throw err; // Re-throw para tratamento superior
    }
};

// Montagem das Mensagens.
client.on('message', async msg => {
    const user = msg.from;
    const message = msg.body.trim();

    // Log de recebimento de cada mensagem
    await registrarInteracao(
        user,
        'MENSAGEM_RECEBIDA',
        message,
        null,
        userState[user]?.etapa || 'inicio',
        'RECEBIDO',
        {}
    );

    if (!userState[user]) {
        userState[user] = {};
    }

    // Chamada do Menu Principal.
    if (message.toLowerCase() === 'menu') {
        userState[user] = { etapa: 'menu' };
        const menuMsg = 'Menu Principal:\n1 - Entradas\n2 - Saídas\n3 - Ver Saldo\n4 - Carteiras\n5 - Categorias\n6 - Relatórios\n7 - Manutenções\n8 - Ajuda\n9 - Assinatura';
        await client.sendMessage(user, menuMsg);
        
        // Log do menu
        await registrarInteracao(
            user,
            'MENU_PRINCIPAL',
            message,
            menuMsg,
            'menu',
            'EXIBIDO',
            {}
        );
    }
    if (userState[user]?.etapa === 'menu' && ['1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(message)) {
        switch (message) {
            case '1':
                userState[user] = { etapa: 'valor', tipo: 'Crédito' };
                await client.sendMessage(user, 'Informe o valor da entrada:');
                
                // Log do acesso ao menu de entrada
                await registrarInteracao(
                    user,
                    'MENU_ENTRADA',
                    message,
                    'Menu de Entrada acessado',
                    'menu_entrada',
                    'EXIBIDO',
                    {}
                );
                break;
            case '2':
                userState[user] = { etapa: 'valor', tipo: 'Débito' };
                await client.sendMessage(user, 'Informe o valor da saída:');
                
                // Log do acesso ao menu de saida
                await registrarInteracao(
                    user,
                    'MENU_SAIDA',
                    message,
                    'Menu de Saida acessado',
                    'menu_saida',
                    'EXIBIDO',
                    {}
                );
                break;
            case '3':
                const result = await consultarSaldo(client, user);
                if (result && result.etapa) {
                    userState[user].etapa = result.etapa;
                }

                // Log do acesso ao menu de saldo
                await registrarInteracao(
                    user,
                    'MENU_SALDO',
                    message,
                    'Menu de Saldo acessado',
                    'menu_saldo',
                    'EXIBIDO',
                    {}
                );
                break;
            case '4':
                userState[user] = { etapa: 'menu_carteiras' };
                await client.sendMessage(user, 'Menu Carteiras:\n1 - Listar Carteiras\n2 - Cadastrar Carteira');
                
                // Log do acesso ao menu de carteiras
                await registrarInteracao(
                    user,
                    'MENU_CARTEIRAS',
                    message,
                    'Menu de Carteiras acessado',
                    'menu_carteiras',
                    'EXIBIDO',
                    {}
                );
                break;
            case '5':
                userState[user] = { etapa: 'menu_categorias' };
                await client.sendMessage(user, 'Menu Categorias:\n1 - Listar Categorias\n2 - Cadastrar Categoria\n3 - Excluir Categoria');
                
                // Log do acesso ao menu de categorias
                await registrarInteracao(
                    user,
                    'MENU_CATEGORIAS',
                    message,
                    'Menu de Categorias acessado',
                    'menu_categorias',
                    'EXIBIDO',
                    {}
                );
                break;
            case '6':
                userState[user] = { etapa: 'menu_relatorios' };
                await client.sendMessage(user, 'Menu Relatórios:\n1 - Extrato em PDF\n2 - Extrato em Excel');

                // Log do acesso ao menu de relatorios
                await registrarInteracao(
                    user,
                    'MENU_RELATORIOS',
                    message,
                    'Menu de Relatorios acessado',
                    'menu_relatorios',
                    'EXIBIDO',
                    {}
                );
                break;
            case '7':
                userState[user] = { etapa: 'menu_manutencoes' };
                await client.sendMessage(user, 'A opção de Manutenções será implementada em breve.');

                // Log do acesso ao menu de manutencoes
                await registrarInteracao(
                    user,
                    'MENU_MANUTENCOES',
                    message,
                    'Menu de Manutencoes acessado',
                    'menu_manutencoes',
                    'EXIBIDO',
                    {}
                );
                break;
            case '8':
                userState[user] = { etapa: 'menu_ajuda' };
                await client.sendMessage(user, 'Menu de Ajuda:\n1 - Guia Rápido\n2 - Gestão Financeira\n3 - Consultas e Saldo\n4 - Relatórios e Análises\n5 - Personalização\n6 - Dicas Financeiras\n7 - FAQ\n8 - Comandos de Voz\n9 - Tutoriais Interativos');
                
                // Log do acesso ao menu de ajuda
                await registrarInteracao(
                    user,
                    'MENU_AJUDA',
                    message,
                    'Menu de Ajuda acessado',
                    'menu_ajuda',
                    'EXIBIDO',
                    {}
                );
                break;
            case '9':
                userState[user] = { etapa: 'menu_assinatura' };
                await client.sendMessage(user, 'Menu Assinatura:\n1 - Ver Planos\n2 - Status da Minha Assinatura\n3 - Cancelar Assinatura');
                return;
        }
        return;
    }

    // Submenu Carteiras
    if (userState[user]?.etapa === 'menu_carteiras' && ['1', '2'].includes(message)) {
        switch (message) {
            case '1':
                await listarCarteiras(client, user);
                break;
            case '2':
                userState[user] = { etapa: 'descricao_carteira' };
                await client.sendMessage(user, 'Informe a descrição da nova carteira:');
                break;
        }
        return;
    }

    // Submenu Categorias
    if (userState[user]?.etapa === 'menu_categorias' && ['1', '2', '3'].includes(message)) {
        switch (message) {
            case '1':
                await listarCategorias(client, user);
                break;
            case '2':
                userState[user] = { etapa: 'descricao_categoria' };
                await client.sendMessage(user, 'Informe a descrição da nova categoria:');
                break;
            case '3':
                const categorias3 = await listCategorias(user);
                const categoriasExclusao = categorias3.filter(cat => cat.Usuario !== 'GERAL'); // Exclui categorias gerais
                if (categoriasExclusao.length > 0) {
                    const listaFormatada = categoriasExclusao.map(cat => `${cat.Codigo} - ${cat.Descricao}`).join('\n');
                    await client.sendMessage(user, `Categorias disponíveis para exclusão:\n${listaFormatada}\n\nInforme o código desejado ou digite "cancelar".`);
                    userState[user] = { etapa: 'aguardando_codigo_exclusao' };
                } else {
                    await client.sendMessage(user, 'Nenhuma categoria encontrada para exclusão.');
                }
                return;
        }
        return;
    }
    
    // Submenu Relatórios
    if (userState[user]?.etapa === 'menu_relatorios' && ['1', '2'].includes(message)) {
        const format = message === '1' ? 'pdf' : 'xml';
        generateStatementReport(client, msg, format);
    }

    // Tratar submenu de assinatura
    if (userState[user]?.etapa === 'menu_assinatura' && ['1', '2', '3'].includes(message)) {
        switch (message) {
            case '1':
                const result = await exibirPlanos(user, client);
                if (result) {
                    userState[user] = result;
                }
                break;
            case '2':
                try {
                    const status = await verificarAssinatura(user);
                    
                    if (status.ativo) {
                        const dataExpiracao = new Date(status.dataExpiracao);
                        const dataFormatada = dataExpiracao.toLocaleDateString('pt-BR');
                        
                        await client.sendMessage(user, 
                            `✅ *Assinatura Ativa*\n` +
                            `🔹 Plano: ${status.plano}\n` +
                            `🔹 Válido até: ${dataFormatada}\n\n` +
                            `Para cancelar sua assinatura, digite "cancelar assinatura"`
                        );
                    } else {
                        await client.sendMessage(user, 
                            `❌ *Você não possui uma assinatura ativa*\n\n` +
                            `Para conhecer nossos planos, digite "planos"`
                        );
                    }
                } catch (error) {
                    console.error('Erro ao verificar status:', error);
                    await client.sendMessage(user, 'Ocorreu um erro ao verificar o status da sua assinatura. Por favor, tente novamente mais tarde.');
                }
                break;
            case '3':
                userState[user] = { etapa: 'confirmar_cancelamento' };
                await client.sendMessage(user, 
                    `⚠️ *Tem certeza que deseja cancelar sua assinatura?*\n\n` +
                    `Ao cancelar, você continuará com acesso até o final do período já pago, mas não será renovada automaticamente.\n\n` +
                    `Digite "confirmar" para prosseguir com o cancelamento ou "voltar" para desistir.`
                );
                break;
        }
        return;
    }

    // Submenu Ajuda
    if (userState[user]?.etapa === 'menu_ajuda' && ['1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(message)) {
        let conteudoAjuda = '';
        
        switch (message) {
            case '1': // Guia Rápido
                conteudoAjuda = 'GUIA RÁPIDO DE USO 📱\n\n' +
                    'Bem-vindo ao assistente financeiro! Aqui está um guia rápido para começar:\n\n' +
                    '1️⃣ Para registrar uma entrada de dinheiro, digite "entrada" ou use o menu principal opção 1\n\n' +
                    '2️⃣ Para registrar uma saída, digite "saída" ou use o menu principal opção 2\n\n' +
                    '3️⃣ Para consultar seu saldo, digite "saldo" ou use o menu principal opção 3\n\n' +
                    '4️⃣ Para listar suas carteiras, digite "listar carteiras"\n\n' +
                    '5️⃣ Para listar suas categorias, digite "listar categorias"\n\n' +
                    '6️⃣ Para obter um relatório, digite "pdf" ou "excel"\n\n' +
                    '7️⃣ Para cancelar qualquer operação, digite "cancelar"\n\n' +
                    '8️⃣ Para retornar ao menu principal, digite "menu"\n\n' +
                    'Experimente essas opções para começar. Para ajuda mais detalhada, consulte as outras opções do menu de ajuda.';
                break;
                
            case '2': // Gestão Financeira
                conteudoAjuda = 'GESTÃO FINANCEIRA 💰\n\n' +
                    'Como registrar entradas e saídas:\n\n' +
                    '📥 PARA REGISTRAR UMA ENTRADA:\n' +
                    '   1. Digite "entrada" ou selecione opção 1 no menu\n' +
                    '   2. Informe o valor (ex: 100,50)\n' +
                    '   3. Selecione a carteira pelo código\n' +
                    '   4. Selecione a categoria pelo código\n' +
                    '   5. Confirme digitando "ok"\n\n' +
                    '📤 PARA REGISTRAR UMA SAÍDA:\n' +
                    '   1. Digite "saída" ou selecione opção 2 no menu\n' +
                    '   2. Siga os mesmos passos da entrada\n\n' +
                    '📋 DICAS IMPORTANTES:\n' +
                    '   • Organize suas despesas por categorias\n' +
                    '   • Registre despesas assim que ocorrerem\n' +
                    '   • Use categorias específicas para facilitar análises futuras\n' +
                    '   • Verifique seus saldos regularmente\n\n' +
                    'Para um controle financeiro eficiente, registre todas as transações, mesmo as pequenas.';
                break;
                
            case '3': // Consultas e Saldo
                conteudoAjuda = 'CONSULTAS E SALDO 📊\n\n' +
                    '🔎 COMO CONSULTAR SEU SALDO:\n' +
                    '   • Digite "saldo" ou selecione opção 3 no menu principal\n' +
                    '   • Se tiver várias carteiras, selecione uma pelo código\n' +
                    '   • O saldo atual será exibido\n\n' +
                    '📱 ATALHOS ÚTEIS:\n' +
                    '   • "saldo" - consulta rápida de saldo\n' +
                    '   • "listar carteiras" - ver todas suas carteiras\n' +
                    '   • "listar categorias" - ver todas suas categorias\n\n' +
                    '💡 DICAS:\n' +
                    '   • Consulte o saldo frequentemente para manter controle\n' +
                    '   • Verifique se todas as transações foram registradas\n' +
                    '   • Use os relatórios para uma visão mais detalhada\n' +
                    '   • Crie carteiras diferentes para necessidades específicas (pessoal, negócios, etc.)';
                break;
                
            case '4': // Relatórios e Análises
                conteudoAjuda = 'RELATÓRIOS E ANÁLISES 📈\n\n' +
                    '📄 COMO GERAR RELATÓRIOS:\n' +
                    '   • Digite "pdf" ou "excel" para atalho rápido\n' +
                    '   • Ou acesse o menu principal opção 6\n' +
                    '   • Selecione o formato desejado (PDF ou Excel)\n' +
                    '   • Escolha a carteira para o relatório\n' +
                    '   • Defina o período desejado\n\n' +
                    '📊 TIPOS DE RELATÓRIOS:\n' +
                    '   • PDF: Extrato detalhado com gráficos e resumo por categoria\n' +
                    '   • Excel: Planilha completa para análises personalizadas\n\n' +
                    '🔍 COMO ANALISAR SEUS DADOS:\n' +
                    '   • Verifique os totais por categoria\n' +
                    '   • Identifique tendências de gastos\n' +
                    '   • Compare diferentes períodos\n' +
                    '   • Monitore sua evolução financeira\n\n' +
                    '💡 DICAS:\n' +
                    '   • Gere relatórios mensais para acompanhamento\n' +
                    '   • Use os dados para estabelecer um orçamento\n' +
                    '   • Identifique onde pode economizar';
                break;
                
            case '5': // Personalização
                conteudoAjuda = 'PERSONALIZAÇÃO 🛠️\n\n' +
                    '💼 COMO GERENCIAR CARTEIRAS:\n' +
                    '   • Para criar uma carteira:\n' +
                    '     - Digite "cadastrar carteira" ou use o menu 4 opção 2\n' +
                    '     - Informe a descrição e escolha o tipo\n\n' +
                    '   • Para listar suas carteiras:\n' +
                    '     - Digite "listar carteiras" ou use o menu 4 opção 1\n\n' +
                    '🏷️ COMO GERENCIAR CATEGORIAS:\n' +
                    '   • Para criar uma categoria:\n' +
                    '     - Digite "cadastrar categoria" ou use o menu 5 opção 2\n' +
                    '     - Informe a descrição da categoria\n\n' +
                    '   • Para listar suas categorias:\n' +
                    '     - Digite "listar categorias" ou use o menu 5 opção 1\n\n' +
                    '   • Para excluir uma categoria:\n' +
                    '     - Digite "excluir categoria" ou use o menu 5 opção 3\n' +
                    '     - Selecione a categoria pelo código\n\n' +
                    '💡 DICAS DE ORGANIZAÇÃO:\n' +
                    '   • Crie categorias específicas para melhor controle\n' +
                    '   • Use carteiras diferentes para separar gastos pessoais e profissionais\n' +
                    '   • Revise suas categorias periodicamente';
                break;
                
            case '6': // Dicas Financeiras
                conteudoAjuda = 'DICAS FINANCEIRAS 💡\n\n' +
                    '1️⃣ ORÇAMENTO\n' +
                    '   • Estabeleça um orçamento mensal realista\n' +
                    '   • Registre todas as despesas, mesmo as pequenas\n' +
                    '   • Compare gastos reais com o orçamento regularmente\n\n' +
                    '2️⃣ POUPANÇA\n' +
                    '   • Separe pelo menos 10% da sua renda para poupar\n' +
                    '   • Crie uma categoria "Poupança" para registrar transferências\n' +
                    '   • Estabeleça objetivos de poupança de curto e longo prazo\n\n' +
                    '3️⃣ REDUÇÃO DE GASTOS\n' +
                    '   • Identifique gastos desnecessários através dos relatórios\n' +
                    '   • Procure padrões de despesas que podem ser reduzidos\n' +
                    '   • Compare os gastos mês a mês para monitorar progresso\n\n' +
                    '4️⃣ CATEGORIZAÇÃO EFICIENTE\n' +
                    '   • Use categorias específicas invés de genéricas\n' +
                    '   • Crie subcategorias para gastos maiores\n' +
                    '   • Revise periodicamente suas categorias\n\n' +
                    '5️⃣ MONITORAMENTO CONSTANTE\n' +
                    '   • Verifique seu saldo frequentemente\n' +
                    '   • Gere relatórios mensais para análise\n' +
                    '   • Ajuste seu planejamento baseado nos resultados';
                break;
                
            case '7': // FAQ
                conteudoAjuda = 'PERGUNTAS FREQUENTES (FAQ) ❓\n\n' +
                    '❓ Como posso corrigir uma transação com erro?\n' +
                    '✅ No momento, não é possível editar transações. Recomendamos registrar uma transação contrária para compensar e então registrar a correta.\n\n' +
                    '❓ Posso exportar meus dados para outro sistema?\n' +
                    '✅ Sim, você pode exportar seus dados através dos relatórios em Excel.\n\n' +
                    '❓ Meus dados estão seguros?\n' +
                    '✅ Sim, seus dados são armazenados com segurança e não são compartilhados.\n\n' +
                    '❓ Posso acessar por outros dispositivos?\n' +
                    '✅ Este é um assistente via WhatsApp, então você pode acessar de qualquer dispositivo com seu WhatsApp instalado.\n\n' +
                    '❓ Como faço backup dos meus dados?\n' +
                    '✅ Seus dados são armazenados automaticamente em nosso servidor. Você pode gerar relatórios periodicamente para ter seus próprios backups.\n\n' +
                    '❓ Posso compartilhar uma carteira com outra pessoa?\n' +
                    '✅ Atualmente não há função de compartilhamento. Cada usuário tem acesso apenas às suas próprias carteiras.\n\n' +
                    '❓ Como resolvo se o bot parar de responder?\n' +
                    '✅ Digite "menu" para reiniciar a interação ou aguarde alguns instantes e tente novamente.';
                break;
                
            case '8': // Comandos de Voz
                conteudoAjuda = 'COMANDOS E ATALHOS 🔍\n\n' +
                    '⚡ COMANDOS RÁPIDOS:\n' +
                    '   • "menu" - Abre o menu principal\n' +
                    '   • "entrada" - Inicia registro de entrada\n' +
                    '   • "saída" ou "saida" - Inicia registro de saída\n' +
                    '   • "saldo" - Consulta saldo\n' +
                    '   • "cancelar" - Cancela operação atual\n' +
                    '   • "pdf" - Gera relatório em PDF\n' +
                    '   • "excel" - Gera relatório em Excel\n' +
                    '   • "listar carteiras" - Mostra suas carteiras\n' +
                    '   • "listar categorias" - Mostra suas categorias\n' +
                    '   • "cadastrar carteira" - Inicia cadastro de carteira\n' +
                    '   • "cadastrar categoria" - Inicia cadastro de categoria\n' +
                    '   • "excluir categoria" - Inicia exclusão de categoria\n\n' +
                    '💡 DICAS DE USO:\n' +
                    '   • Você pode enviar mensagens de voz que serão convertidas em texto (em breve)\n' +
                    '   • Use comandos rápidos para economizar tempo\n' +
                    '   • Mantenha suas transações em dia para relatórios precisos';
                break;

            case '9': // Tutoriais Interativos (Nova opção)
                userState[user] = { etapa: 'menu_tutoriais' };
                await client.sendMessage(user, 'Tutoriais Interativos 🎓\n\n' +
                    'Aprenda na prática como usar o sistema:\n\n' +
                    '1 - Como registrar uma entrada\n' +
                    '2 - Como registrar uma saída\n' +
                    '3 - Como gerar um relatório\n' +
                    '4 - Como criar uma nova categoria\n\n' +
                    'Escolha uma opção para iniciar o tutorial:');
                
                await registrarInteracao(
                    user,
                    'MENU_TUTORIAIS',
                    message,
                    'Menu de tutoriais interativos exibido',
                    'tutoriais',
                    'EXIBIDO',
                    {}
                );
            return;
        }
        
        // Enviar o conteúdo de ajuda ao usuário
        await client.sendMessage(user, conteudoAjuda);
        
        // Log da interação com a ajuda específica
        await registrarInteracao(
            user,
            'CONTEUDO_AJUDA',
            message,
            `Conteúdo de ajuda exibido: opção ${message}`,
            'visualizacao_ajuda',
            'EXIBIDO',
            { opcaoAjuda: message }
        );
        
        // Perguntar se o usuário deseja ver outra opção de ajuda
        setTimeout(async () => {
            await client.sendMessage(user, 'Posso ajudar com mais alguma informação? Digite o número da opção desejada ou "menu" para voltar ao menu principal.');
        }, 2000); // Pequeno delay para melhor experiência do usuário
        
        return;
    }

    // Atalho das chamadas 'entrada' e 'saída'.
    if (message.toLowerCase() === 'entrada' || ['saída', 'saida'].includes(message.toLowerCase())) {
        userState[user] = { etapa: 'valor', tipo: message.toLowerCase() === 'entrada' ? 'Crédito' : 'Débito' };
        await client.sendMessage(user, 'Qual valor?');
        return;
    }
    
    if (userState[user].etapa === 'valor') {
        const valor = parseFloat(message.replace(',', '.'));
        if (isNaN(valor) || valor <= 0) {
            await client.sendMessage(user, 'Valor inválido. Por favor, digite um número válido.');
            return;
        }
        userState[user].valor = valor.toFixed(2); // Manter o valor original formatado para cálculos
    
        // Adicionar uma propriedade para o valor formatado para exibição
        userState[user].valorFormatado = new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(valor);
        
        const carteiras = await getCarteiras(user);

        if (carteiras.length === 1 && carteiras[0].Codigo === 1) { // Verificação ajustada para número
            userState[user].carteira = 1;
            userState[user].etapa = 'categoria';
            const categorias = await getCategorias(user);
            const categoriaMsg = categorias.map(c => `${c.Codigo} - ${c.Descricao}`).join('\n');
            await client.sendMessage(user, `Qual categoria?\n${categoriaMsg}\n(Envie o código da categoria)`);
            return;
        }

        userState[user].etapa = 'carteira';
        const carteiraMsg = carteiras.map(c => `${c.Codigo} - ${c.Descricao}`).join('\n');
        await client.sendMessage(user, `Qual carteira?\n${carteiraMsg}\n(Envie o código da carteira)`);
        return;
    }

    if (userState[user].etapa === 'carteira') {
        const carteiras = await getCarteiras(user);
        const carteiraSelecionada = carteiras.find(c => String(c.Codigo) === String(message));
        if (!carteiraSelecionada) {
            await client.sendMessage(user, 'Código de carteira inválido. Escolha uma das opções apresentadas.');
            return;
        }
        userState[user].carteira = carteiraSelecionada.Codigo;
        userState[user].etapa = 'categoria';
        const categorias = await getCategorias(user);

        const categoriaMsg = categorias.map(c => `${c.Codigo} - ${c.Descricao}`).join('\n');
        await client.sendMessage(user, `Qual categoria?\n${categoriaMsg}\n(Envie o código da categoria)`);
        return;
    }

    if (userState[user].etapa === 'categoria') {
        const categorias = await getCategorias(user);
        const categoriaSelecionada = categorias.find(c => c.Codigo === parseInt(message));
        if (!categoriaSelecionada) {
            await client.sendMessage(user, 'Código de categoria inválido. Escolha uma das opções apresentadas.');
            return;
        }
        userState[user].categoria = categoriaSelecionada.Codigo;
        userState[user].etapa = 'confirmacao';
    
    
        const carteiras = await getCarteiras(user); // Busca a lista de carteiras novamente
        const carteiraDescricao = carteiras.find(c => c.Codigo === userState[user].carteira)?.Descricao || 'Não encontrado';
        const resumo = `Confirme os dados:\nTipo: ${userState[user].tipo}\nValor: ${userState[user].valorFormatado}\nCarteira: ${userState[user].carteira} - ${carteiraDescricao}\nCategoria: ${categoriaSelecionada.Codigo} - ${categoriaSelecionada.Descricao}\nResponda "Ok" para salvar.`;
        
        await client.sendMessage(user, resumo);
        
        return;
    }

    if (userState[user].etapa === 'confirmacao' && message.toLowerCase() === 'ok') {
        try {
            await saveTransactionToDB(user, userState[user].tipo, userState[user].valor, userState[user].carteira, userState[user].categoria);
            
            const mensagemSucesso = 'Movimentação registrada com sucesso!';
            await client.sendMessage(user, mensagemSucesso);
            
            // Log da transação bem-sucedida
            await registrarInteracao(
                user,
                userState[user].tipo === 'Crédito' ? 'ENTRADA_FINANCEIRA' : 'SAIDA_FINANCEIRA',
                message,
                mensagemSucesso,
                'confirmacao',
                'SUCESSO',
                {
                    valor: userState[user].valor,
                    carteira: userState[user].carteira,
                    categoria: userState[user].categoria
                }
            );
            
            delete userState[user];
        } catch (error) {
            console.error('Erro ao salvar transação:', error);
            const mensagemErro = 'Erro ao registrar movimentação. Tente novamente.';
            await client.sendMessage(user, mensagemErro);
            
            // Log de erro
            await registrarInteracao(
                user,
                userState[user].tipo === 'Crédito' ? 'ENTRADA_FINANCEIRA' : 'SAIDA_FINANCEIRA',
                message,
                mensagemErro,
                'confirmacao',
                'ERRO',
                {
                    valor: userState[user].valor,
                    carteira: userState[user].carteira,
                    categoria: userState[user].categoria,
                    erro: error.message
                }
            );
        }
        return;
    }

    // Atalho da chamada de Cadastro de Carteira.
    if (message === 'cadastrar carteira') {
        userState[user] = { etapa: 'descricao_carteira' };
        await client.sendMessage(user, 'Qual descrição da carteira?');
        return;
    }

    if (userState[user].etapa === 'descricao_carteira') {
        userState[user].descricaoCarteira = message;
        userState[user].etapa = 'tipo_carteira';
        await client.sendMessage(user, 'Escolha o tipo da carteira:\n1 - Dinheiro\n2 - Cartão de Crédito\n3 - Cartão de Débito\n4 - Conta Bancária');
        return;
    }
    
    if (userState[user]?.etapa === 'tipo_carteira') {
        if (message.toLowerCase() === 'cancelar') {
            const etapaAnterior = userState[user]?.etapa || 'desconhecida';
            const operacaoAtual = userState[user]?.tipo || 'OPERACAO';
            delete userState[user];
            
            const mensagemCancelamento = 'Operação cancelada.';
            await client.sendMessage(user, mensagemCancelamento);
            
            // Log do cancelamento
            await registrarInteracao(
                user,
                'CANCELAMENTO',
                message,
                mensagemCancelamento,
                etapaAnterior,
                'CANCELADO',
                { operacao: operacaoAtual }
            );
            return;
        }
        const tiposCarteira = {
            '1': 'Dinheiro',
            '2': 'Cartão de Crédito',
            '3': 'Cartão de Débito',
            '4': 'Conta Bancária'
        };
    
        const tipoSelecionado = tiposCarteira[message];
        if (!tipoSelecionado) {
            await client.sendMessage(user, 'Opção inválida. Por favor, escolha uma opção válida:\n1 - Dinheiro\n2 - Cartão de Crédito\n3 - Cartão de Débito\n4 - Conta Bancária');
            return;
        }
    
        userState[user].tipoCarteira = tipoSelecionado;
        userState[user].etapa = 'confirmacao_carteira';
        await saveCarteiraToDB(user, userState[user].descricaoCarteira, tipoSelecionado);
        await client.sendMessage(user, `Carteira "${userState[user].descricaoCarteira}" do tipo "${tipoSelecionado}" criada com sucesso!`);
        delete userState[user];
        return;
    }     

    // Atalho da chamada de Cadastro de Categoria.
    if (message === 'cadastrar categoria') {
        userState[user] = { etapa: 'descricao_categoria' };
        await client.sendMessage(user, 'Qual descrição da categoria?');
        return;
    }

    if (userState[user]?.etapa === 'descricao_categoria') {
        if (message.toLowerCase() === 'cancelar') {
            const etapaAnterior = userState[user]?.etapa || 'desconhecida';
            const operacaoAtual = userState[user]?.tipo || 'OPERACAO';
            delete userState[user];
            
            const mensagemCancelamento = 'Operação cancelada.';
            await client.sendMessage(user, mensagemCancelamento);
            
            // Log do cancelamento
            await registrarInteracao(
                user,
                'CANCELAMENTO',
                message,
                mensagemCancelamento,
                etapaAnterior,
                'CANCELADO',
                { operacao: operacaoAtual }
            );
            return;
        }

        const categoriaExistente = await checkCategoriaExists(user, message.trim().toLowerCase());
        if (categoriaExistente) {
            await client.sendMessage(user, 'Esta categoria já existe. Por favor, escolha outra descrição.');
            return;
        }

        await saveCategoriaToDB(user, message.trim());
        await client.sendMessage(user, 'Categoria cadastrada com sucesso!');
        delete userState[user];
        return;
    }

    // Etapas para exclusão de Categoria via Menu.
    if (userState[user]?.etapa === 'aguardando_codigo_exclusao') {
        if (message.toLowerCase() === 'cancelar') {
            const etapaAnterior = userState[user]?.etapa || 'desconhecida';
            const operacaoAtual = userState[user]?.tipo || 'OPERACAO';
            delete userState[user];
            
            const mensagemCancelamento = 'Operação cancelada.';
            await client.sendMessage(user, mensagemCancelamento);
            
            // Log do cancelamento
            await registrarInteracao(
                user,
                'CANCELAMENTO',
                message,
                mensagemCancelamento,
                etapaAnterior,
                'CANCELADO',
                { operacao: operacaoAtual }
            );
            return;
        }
        await deleteCategoriaFromDB(user, message); // Usa o código informado para excluir
        userState[user] = { etapa: 'menu_categorias' }; // Volta pro menu de categorias após a exclusão
        await client.sendMessage(user, 'Categoria excluída com sucesso!');
        return;
    }

    // Atalho da chamada de Exclusão de Categoria.
    if (message === 'excluir categoria') {
        const categorias = await listCategorias(user);
        
        if (!categorias || categorias.length === 0) {
            await client.sendMessage(user, 'Não há categorias cadastradas para excluir.');
            return;
        }
        
        const categoriasUsuario = categorias.filter(cat => cat.Usuario?.trim().toLowerCase() === user.trim().toLowerCase());
         
        if (categoriasUsuario.length === 0) {
            await client.sendMessage(user, 'Não há categorias próprias cadastradas para excluir.');
            return;
        }
    
        let listaFormatada = 'Escolha a categoria que deseja excluir, informando o código correspondente:\n';
        categoriasUsuario.forEach(cat => {
            listaFormatada += `${cat.Codigo} - ${cat.Descricao}\n`;
        });
    
        userState[user] = { etapa: 'selecionar_categoria_exclusao', categorias: categoriasUsuario };
        await client.sendMessage(user, listaFormatada);
        return;
    }

    if (userState[user]?.etapa === 'selecionar_categoria_exclusao') {
        if (message.toLowerCase() === 'cancelar') {
            const etapaAnterior = userState[user]?.etapa || 'desconhecida';
            const operacaoAtual = userState[user]?.tipo || 'OPERACAO';
            delete userState[user];
            
            const mensagemCancelamento = 'Operação cancelada.';
            await client.sendMessage(user, mensagemCancelamento);
            
            // Log do cancelamento
            await registrarInteracao(
                user,
                'CANCELAMENTO',
                message,
                mensagemCancelamento,
                etapaAnterior,
                'CANCELADO',
                { operacao: operacaoAtual }
            );
            return;
        }
    
        const categoriaSelecionada = userState[user].categorias.find(cat => cat.Codigo === parseInt(message));
    
        if (!categoriaSelecionada) {
            await client.sendMessage(user, 'Código inválido. Por favor, selecione um código da lista.');
            return;
        }
    
        if (categoriaSelecionada.Usuario !== user) {
            await client.sendMessage(user, 'Você só pode excluir categorias que você mesmo criou.');
            delete userState[user];
            return;
        }
    
        const codigoCategoria = parseInt(categoriaSelecionada.Codigo);
    
        if (isNaN(codigoCategoria)) {
            await client.sendMessage(user, 'Houve um erro ao interpretar o código da categoria. Tente novamente.');
            delete userState[user];
            return;
        }
    
        const categoriaEmUso = await checkCategoriaInUse(user, codigoCategoria);
        if (categoriaEmUso) {
            await client.sendMessage(user, 'Esta categoria já foi utilizada e não poderá ser excluída.');
            delete userState[user];
            return;
        }
    
        const categoriaExcluida = await deleteCategoriaFromDB(user, categoriaSelecionada.Codigo);
        if (categoriaExcluida) {
            await client.sendMessage(user, 'Categoria excluída com sucesso!');
        } else {
            await client.sendMessage(user, 'Ocorreu um erro ao tentar excluir a categoria.');
        }
    
        delete userState[user];
        return;
    }

    // Atalho da chamada que cancela a operação.
    if (message.toLowerCase() === 'cancelar') {
        const etapaAnterior = userState[user]?.etapa || 'desconhecida';
        const operacaoAtual = userState[user]?.tipo || 'OPERACAO';
        delete userState[user];
        
        const mensagemCancelamento = 'Operação cancelada.';
        await client.sendMessage(user, mensagemCancelamento);
        
        // Log do cancelamento
        await registrarInteracao(
            user,
            'CANCELAMENTO',
            message,
            mensagemCancelamento,
            etapaAnterior,
            'CANCELADO',
            { operacao: operacaoAtual }
        );
        return;
    }

    // Atalho da chamada de Saldo.
    if (message.toLowerCase() === 'saldo') {
        const result = await consultarSaldo(client, user);
        if (result && result.etapa) {
            userState[user].etapa = result.etapa;
        }
        return;
    }

    // Atalho da chamada Listar Carteiras.
    if (message.toLowerCase() === 'listar carteiras') {
        await listarCarteiras(client, user);
        return;
    }
        
    // Atalho da chamada Listar Categorias.
    if (message.toLowerCase() === 'listar categorias') {
        await listarCategorias(client, user);
        return;
    }

    // Atalhos para relatórios em PDF
    if (['relatorio pdf', 'pdf'].includes(message.toLowerCase())) {
        // Log do atalho
        await registrarInteracao(
            user,
            'ATALHO_RELATORIO',
            message,
            'Iniciando processo de relatório PDF via atalho',
            'atalho_pdf',
            'INICIADO',
            { format: 'pdf' }
        );
        
        // Verificar se já existe um processo em andamento para este usuário
        if (userState[user]?.etapa?.startsWith('relatorio_')) {
            await client.sendMessage(user, 'Você já tem um processo de relatório em andamento. Por favor, conclua-o ou digite "cancelar" para interromper.');
            return;
        }
        
        // Iniciar a geração do relatório através do fluxo normal
        generateStatementReport(client, msg, 'pdf');
        return;
    }

    // Atalhos para relatórios em XML/Excel
    if (['relatorio xml', 'xml', 'relatorio excel', 'excel'].includes(message.toLowerCase())) {
        // Log do atalho
        await registrarInteracao(
            user,
            'ATALHO_RELATORIO',
            message,
            'Iniciando processo de relatório Excel via atalho',
            'atalho_excel',
            'INICIADO',
            { format: 'xml' }
        );
        
        // Verificar se já existe um processo em andamento para este usuário
        if (userState[user]?.etapa?.startsWith('relatorio_')) {
            await client.sendMessage(user, 'Você já tem um processo de relatório em andamento. Por favor, conclua-o ou digite "cancelar" para interromper.');
            return;
        }
        
        // Iniciar a geração do relatório através do fluxo normal
        generateStatementReport(client, msg, 'xml');
        return;
    }

    // Lidar com seleção de carteira para saldo
    if (userState[user]?.etapa === 'selecionarCarteiraSaldo') {
        const carteiras = await getCarteiras(user);
        const carteiraSelecionada = carteiras.find(c => c.Codigo === parseInt(message));
        
        if (!carteiraSelecionada) {
            await client.sendMessage(user, 'Código de carteira inválido. Escolha uma das opções apresentadas.');
            return;
        }
        
        await exibirSaldo(client, user, carteiraSelecionada.Codigo);
        delete userState[user].etapa;
        return;
    }

    // Adicionar novos comandos para gerenciar usuários (apenas para administradores)
    async function isAdminUser(user) {
        // Implementar lógica para identificar administradores
        // Por exemplo, uma lista de números de telefone de administradores
        const adminUsers = ['554396697747@c.us']; // Exemplo, substituir pelos números reais
        return adminUsers.includes(user);
    }
    
    // Dentro do event handler 'message', adicionar os comandos de administração
    if (message.toLowerCase() === 'admin menu' && await isAdminUser(user)) {
        await client.sendMessage(user, 'Menu de Administração:\n1 - Listar Usuários\n2 - Tornar Usuário PRO\n3 - Desativar Usuário\n4 - Reativar Usuário');
        userState[user] = { etapa: 'admin_menu' };
        return;
    }

    // Processar a seleção do menu de administração
    if (userState[user]?.etapa === 'admin_menu' && await isAdminUser(user)) {
        switch (message) {
            case '1': // Listar Usuários
                // Implementar função para listar usuários
                await listUsers(user);
                break;
            case '2': // Tornar Usuário PRO
                userState[user] = { etapa: 'set_user_pro' };
                await client.sendMessage(user, 'Digite o número do telefone do usuário que deseja tornar PRO (formato: 55119999999@c.us):');
                break;
            case '3': // Desativar Usuário
                userState[user] = { etapa: 'deactivate_user' };
                await client.sendMessage(user, 'Digite o número do telefone do usuário que deseja desativar (formato: 55119999999@c.us):');
                break;
            case '4': // Reativar Usuário
                userState[user] = { etapa: 'reactivate_user' };
                await client.sendMessage(user, 'Digite o número do telefone do usuário que deseja reativar (formato: 55119999999@c.us):');
                break;
        }
        return;
    }

    // Verificar acesso a recursos premium
    async function verificarAcessoPremium(user, client) {
        try {
            const statusAssinatura = await verificarAssinatura(user);
            
            if (!statusAssinatura.ativo) {
                // O usuário não tem acesso PRO
                await client.sendMessage(user, 'Esta funcionalidade é exclusiva para assinantes PRO. Para conhecer nossos planos, digite "planos".');
                return false;
            }
            
            return true;
        } catch (error) {
            console.error('Erro ao verificar acesso premium:', error);
            await client.sendMessage(user, 'Não foi possível verificar seu status de assinatura. Por favor, tente novamente mais tarde.');
            return false;
        }
    }

    // Exibir menu de planos
    async function exibirPlanos(user, client) {
        try {
            const mensagem = `🌟 *PLANOS DE ASSINATURA* 🌟\n\n` +
                `*Plano Mensal*\n` +
                `💰 R$ ${PLANOS.MENSAL.valor.toFixed(2).replace('.', ',')}/mês\n` +
                `✅ Acesso a todas as funcionalidades\n` +
                `✅ Relatórios ilimitados\n` +
                `✅ Suporte prioritário\n\n` +
                
                `*Plano Anual*\n` +
                `💰 R$ ${PLANOS.ANUAL.valor.toFixed(2).replace('.', ',')}/ano\n` +
                `✅ Acesso a todas as funcionalidades\n` +
                `✅ Relatórios ilimitados\n` +
                `✅ Suporte prioritário\n` +
                `✅ Economia de ${(PLANOS.MENSAL.valor * 12 - PLANOS.ANUAL.valor).toFixed(2).replace('.', ',')} reais\n\n` +
                
                `Para assinar, digite:\n` +
                `1 - Plano Mensal\n` +
                `2 - Plano Anual`;
            
            await client.sendMessage(user, mensagem);
            
            // Log da exibição de planos
            await registrarInteracao(
                user,
                'EXIBIR_PLANOS',
                'Exibição de planos',
                mensagem,
                'assinatura',
                'EXIBIDO',
                {}
            );
            
            return { etapa: 'selecionar_plano' };
        } catch (error) {
            console.error('Erro ao exibir planos:', error);
            await client.sendMessage(user, 'Ocorreu um erro ao exibir os planos disponíveis. Por favor, tente novamente mais tarde.');
            return null;
        }
    }

    // Implementar função para listar usuários (apenas para admins)
    async function listUsers(adminUser) {
        if (!await isAdminUser(adminUser)) return;
        
        try {
            const pool = await getConnection();
            const result = await pool.request()
                .query(`
                    SELECT TOP 20 Telefone, Nome, 
                        CASE WHEN UsuarioPro = 1 THEN 'Sim' ELSE 'Não' END AS Pro,
                        CASE WHEN Ativo = 1 THEN 'Sim' ELSE 'Não' END AS Ativo,
                        FORMAT(UltimaAtividade, 'dd/MM/yyyy HH:mm') AS UltimaAtiv
                    FROM Usuarios
                    ORDER BY UltimaAtividade DESC
                `);
            
            if (result.recordset.length === 0) {
                await client.sendMessage(adminUser, 'Nenhum usuário registrado.');
                return;
            }
            
            let message = 'Últimos 20 usuários ativos:\n\n';
            result.recordset.forEach(user => {
                message += `📱 ${user.Telefone}\n`;
                message += `👤 ${user.Nome || 'Nome não registrado'}\n`;
                message += `✅ PRO: ${user.Pro} | Ativo: ${user.Ativo}\n`;
                message += `⏱️ Última atividade: ${user.UltimaAtiv}\n\n`;
            });
            
            await client.sendMessage(adminUser, message);
        } catch (error) {
            console.error('Erro ao listar usuários:', error);
            await client.sendMessage(adminUser, 'Ocorreu um erro ao listar os usuários.');
        }
    }

    // Processar comandos de administração de usuários
    if (userState[user]?.etapa === 'set_user_pro' && await isAdminUser(user)) {
        const targetUser = message.trim();
        try {
            await userManager.updateUserProStatus(targetUser, true);
            await client.sendMessage(user, `Usuário ${targetUser} agora é PRO!`);
        } catch (error) {
            console.error('Erro ao atualizar status PRO:', error);
            await client.sendMessage(user, 'Ocorreu um erro ao atualizar o status do usuário.');
        }
        delete userState[user];
        return;
    }

    if (userState[user]?.etapa === 'deactivate_user' && await isAdminUser(user)) {
        const targetUser = message.trim();
        try {
            await userManager.deactivateUser(targetUser);
            await client.sendMessage(user, `Usuário ${targetUser} foi desativado.`);
        } catch (error) {
            console.error('Erro ao desativar usuário:', error);
            await client.sendMessage(user, 'Ocorreu um erro ao desativar o usuário.');
        }
        delete userState[user];
        return;
    }

    if (userState[user]?.etapa === 'reactivate_user' && await isAdminUser(user)) {
        const targetUser = message.trim();
        try {
            await userManager.reactivateUser(targetUser);
            await client.sendMessage(user, `Usuário ${targetUser} foi reativado.`);
        } catch (error) {
            console.error('Erro ao reativar usuário:', error);
            await client.sendMessage(user, 'Ocorreu um erro ao reativar o usuário.');
        }
        delete userState[user];
        return;
    }

    // Gerenciador de tutoriais interativos
    if (userState[user]?.etapa === 'menu_tutoriais' && ['1', '2', '3', '4'].includes(message)) {
        // Determinar qual tutorial iniciar
        switch (message) {
            case '1': // Tutorial de registro de entrada
                userState[user] = { 
                    etapa: 'tutorial_entrada',
                    passo: 1,
                    tutorial: {
                        tipo: 'Crédito',
                        valorExemplo: 50.00,
                        carteiraExemplo: 1,
                        categoriaExemplo: 1
                    }
                };
                
                // Iniciar o tutorial
                await iniciarTutorialEntrada(client, user);
                break;
                
            case '2': // Tutorial de registro de saída
                userState[user] = { 
                    etapa: 'tutorial_saida',
                    passo: 1,
                    tutorial: {
                        tipo: 'Débito',
                        valorExemplo: 25.50,
                        carteiraExemplo: 1,
                        categoriaExemplo: 2
                    }
                };
                
                // Iniciar o tutorial
                await iniciarTutorialSaida(client, user);
                break;
                
            case '3': // Tutorial de relatório
                userState[user] = { 
                    etapa: 'tutorial_relatorio',
                    passo: 1
                };
                
                // Iniciar o tutorial
                await iniciarTutorialRelatorio(client, user);
                break;
                
            case '4': // Tutorial de criação de categoria
                userState[user] = { 
                    etapa: 'tutorial_categoria',
                    passo: 1
                };
                
                // Iniciar o tutorial
                await iniciarTutorialCategoria(client, user);
                break;
        }
        
        await registrarInteracao(
            user,
            'INICIO_TUTORIAL',
            message,
            `Tutorial ${message} iniciado`,
            'tutorial_iniciado',
            'INICIADO',
            { tutorial: message }
        );
        
        return;
    }

    // Função para iniciar o tutorial de registro de entrada
    async function iniciarTutorialEntrada(client, user) {
        // Enviar mensagem de boas-vindas ao tutorial
        await client.sendMessage(user, '🎓 *TUTORIAL: COMO REGISTRAR UMA ENTRADA* 🎓\n\n' +
            'Vamos aprender passo a passo como registrar uma entrada de dinheiro.\n\n' +
            'Este é um tutorial interativo, onde você irá praticar com valores de exemplo (nenhuma transação real será registrada).\n\n' +
            '👉 Para começar, digite "entrada" como se estivesse iniciando uma transação real.');
        
        // Configurar o estado para capturar a próxima interação
        userState[user].aguardandoComando = true;
    }

    // Função para processar os passos do tutorial de entrada
    async function processarTutorialEntrada(client, user, message) {
        const passo = userState[user].passo;
        const tutorial = userState[user].tutorial;
        
        switch (passo) {
            case 1: // Usuário digitou "entrada"
                if (message.toLowerCase() === 'entrada') {
                    userState[user].passo = 2;
                    
                    // Simular resposta do sistema
                    await client.sendMessage(user, 'Informe o valor da entrada:');
                    
                    // Instrução para o próximo passo
                    setTimeout(async () => {
                        await client.sendMessage(user, '✅ Muito bem! O sistema está pedindo o valor da entrada.\n\n' +
                            `👉 Agora, digite "${tutorial.valorExemplo.toFixed(2).replace('.', ',')}" como valor de exemplo.`);
                    }, 1000);
                } else {
                    await client.sendMessage(user, '❌ Para iniciar o registro de uma entrada, você deve digitar "entrada".\n\n' +
                        '👉 Por favor, digite "entrada" para continuar o tutorial.');
                }
                break;
                
            case 2: // Usuário digitou o valor
                // Verificar se o valor está no formato correto (pode ser mais flexível para fins de tutorial)
                const valorFormatado = message.replace(',', '.');
                const valor = parseFloat(valorFormatado);
                
                if (!isNaN(valor) && valor > 0) {
                    userState[user].passo = 3;
                    
                    // Buscar carteiras para usar no exemplo
                    const carteiras = await getCarteiras(user);
                    let carteiraMsg = '';
                    
                    if (carteiras.length > 0) {
                        carteiraMsg = carteiras.map(c => `${c.Codigo} - ${c.Descricao}`).join('\n');
                    } else {
                        // Se o usuário não tiver carteiras, criar uma mensagem simulada
                        carteiraMsg = '1 - Carteira Principal';
                    }
                    
                    // Simular resposta do sistema
                    await client.sendMessage(user, `Qual carteira?\n${carteiraMsg}\n(Envie o código da carteira)`);
                    
                    // Instrução para o próximo passo
                    setTimeout(async () => {
                        await client.sendMessage(user, '✅ Excelente! O sistema mostrou suas carteiras disponíveis.\n\n' +
                            `👉 Agora, selecione a carteira digitando "${tutorial.carteiraExemplo}".`);
                    }, 1000);
                } else {
                    await client.sendMessage(user, '❌ O valor informado parece não ser válido.\n\n' +
                        `👉 Por favor, digite "${tutorial.valorExemplo.toFixed(2).replace('.', ',')}" como valor de exemplo.`);
                }
                break;
                
            case 3: // Usuário selecionou a carteira
                // Para o tutorial, aceitamos qualquer número como válido
                if (/^\d+$/.test(message)) {
                    userState[user].passo = 4;
                    
                    // Buscar categorias para usar no exemplo
                    const categorias = await getCategorias(user);
                    let categoriaMsg = '';
                    
                    if (categorias.length > 0) {
                        categoriaMsg = categorias.map(c => `${c.Codigo} - ${c.Descricao}`).join('\n');
                    } else {
                        // Se o usuário não tiver categorias, criar uma mensagem simulada
                        categoriaMsg = '1 - Salário\n2 - Rendimentos\n3 - Outros';
                    }
                    
                    // Simular resposta do sistema
                    await client.sendMessage(user, `Qual categoria?\n${categoriaMsg}\n(Envie o código da categoria)`);
                    
                    // Instrução para o próximo passo
                    setTimeout(async () => {
                        await client.sendMessage(user, '✅ Perfeito! O sistema mostrou suas categorias disponíveis.\n\n' +
                            `👉 Agora, selecione a categoria digitando "${tutorial.categoriaExemplo}".`);
                    }, 1000);
                } else {
                    await client.sendMessage(user, '❌ Para selecionar uma carteira, você deve digitar o código numérico dela.\n\n' +
                        `👉 Por favor, digite "${tutorial.carteiraExemplo}" para selecionar a carteira de exemplo.`);
                }
                break;
                
            case 4: // Usuário selecionou a categoria
                // Para o tutorial, aceitamos qualquer número como válido
                if (/^\d+$/.test(message)) {
                    userState[user].passo = 5;
                    
                    // Simular a tela de confirmação
                    const confirmaMsg = `Confirme os dados:\nTipo: ${tutorial.tipo}\nValor: R$ ${tutorial.valorExemplo.toFixed(2).replace('.', ',')}\nCarteira: ${tutorial.carteiraExemplo}\nCategoria: ${tutorial.categoriaExemplo}\nResponda "Ok" para salvar.`;
                    
                    await client.sendMessage(user, confirmaMsg);
                    
                    // Instrução para o próximo passo
                    setTimeout(async () => {
                        await client.sendMessage(user, '✅ Ótimo! O sistema está mostrando um resumo da transação para sua confirmação.\n\n' +
                            '👉 Para finalizar, digite "Ok" para simular a confirmação.');
                    }, 1000);
                } else {
                    await client.sendMessage(user, '❌ Para selecionar uma categoria, você deve digitar o código numérico dela.\n\n' +
                        `👉 Por favor, digite "${tutorial.categoriaExemplo}" para selecionar a categoria de exemplo.`);
                }
                break;
                
            case 5: // Usuário confirmou a transação
                if (message.toLowerCase() === 'ok') {
                    // Simular mensagem de sucesso
                    await client.sendMessage(user, 'Movimentação registrada com sucesso!');
                    
                    // Finalização do tutorial
                    setTimeout(async () => {
                        await client.sendMessage(user, '🎉 *PARABÉNS! VOCÊ COMPLETOU O TUTORIAL!* 🎉\n\n' +
                            'Você aprendeu como registrar uma entrada financeira seguindo estes passos:\n\n' +
                            '1️⃣ Digitar "entrada" para iniciar\n' +
                            '2️⃣ Informar o valor\n' +
                            '3️⃣ Selecionar a carteira\n' +
                            '4️⃣ Selecionar a categoria\n' +
                            '5️⃣ Confirmar a transação\n\n' +
                            'Lembre-se: O que você acabou de fazer foi uma simulação. Nenhuma transação real foi registrada.\n\n' +
                            '✅ Gostaria de:\n' +
                            '1 - Tentar outro tutorial\n' +
                            '2 - Voltar ao menu de ajuda\n' +
                            '3 - Voltar ao menu principal');
                        
                        // Configurar estado para a escolha final
                        userState[user].etapa = 'tutorial_finalizado';
                    }, 1500);
                } else {
                    await client.sendMessage(user, '❌ Para confirmar a transação, você deve digitar "Ok".\n\n' +
                        '👉 Por favor, digite "Ok" para finalizar o tutorial.');
                }
                break;
        }
    }

    // Função para iniciar o tutorial de registro de saída (similar ao de entrada)
    async function iniciarTutorialSaida(client, user) {
        await client.sendMessage(user, '🎓 *TUTORIAL: COMO REGISTRAR UMA SAÍDA* 🎓\n\n' +
            'Vamos aprender passo a passo como registrar uma saída de dinheiro.\n\n' +
            'Este é um tutorial interativo, onde você irá praticar com valores de exemplo (nenhuma transação real será registrada).\n\n' +
            '👉 Para começar, digite "saída" ou "saida" como se estivesse iniciando uma transação real.');
        
        userState[user].aguardandoComando = true;
    }

    // Função para processar os passos do tutorial de saída (implementação similar ao de entrada)
    async function processarTutorialSaida(client, user, message) {
        // Implementação similar ao processarTutorialEntrada com ajustes para saída
        // ...
    }

    // Função para iniciar o tutorial de geração de relatório
    async function iniciarTutorialRelatorio(client, user) {
        await client.sendMessage(user, '🎓 *TUTORIAL: COMO GERAR UM RELATÓRIO* 🎓\n\n' +
            'Vamos aprender passo a passo como gerar um relatório financeiro.\n\n' +
            'Este é um tutorial interativo, onde você irá praticar os comandos (nenhum relatório real será gerado).\n\n' +
            '👉 Para começar, digite "pdf" para simular a geração de um relatório em PDF.');
        
        userState[user].aguardandoComando = true;
    }

    // Função para iniciar o tutorial de criação de categoria
    async function iniciarTutorialCategoria(client, user) {
        await client.sendMessage(user, '🎓 *TUTORIAL: COMO CRIAR UMA NOVA CATEGORIA* 🎓\n\n' +
            'Vamos aprender passo a passo como criar uma nova categoria de despesas ou receitas.\n\n' +
            'Este é um tutorial interativo, onde você irá praticar os comandos (nenhuma categoria real será criada).\n\n' +
            '👉 Para começar, digite "cadastrar categoria" como se estivesse criando uma categoria real.');
        
        userState[user].aguardandoComando = true;
    }

    // Atalho para exibir planos
    if (message.toLowerCase() === 'planos' || message.toLowerCase() === 'assinatura') {
        const result = await exibirPlanos(user, client);
        if (result) {
            userState[user] = result;
        }
        return;
    }

    // Verificar status da assinatura
    if (message.toLowerCase() === 'status' || message.toLowerCase() === 'minha assinatura') {
        try {
            const status = await verificarAssinatura(user);
            
            if (status.ativo) {
                const dataExpiracao = new Date(status.dataExpiracao);
                const dataFormatada = dataExpiracao.toLocaleDateString('pt-BR');
                
                await client.sendMessage(user, 
                    `✅ *Assinatura Ativa*\n` +
                    `🔹 Plano: ${status.plano}\n` +
                    `🔹 Válido até: ${dataFormatada}\n\n` +
                    `Para cancelar sua assinatura, digite "cancelar assinatura"`
                );
            } else {
                await client.sendMessage(user, 
                    `❌ *Você não possui uma assinatura ativa*\n\n` +
                    `Para conhecer nossos planos, digite "planos"`
                );
            }
        } catch (error) {
            console.error('Erro ao verificar status:', error);
            await client.sendMessage(user, 'Ocorreu um erro ao verificar o status da sua assinatura. Por favor, tente novamente mais tarde.');
        }
        return;
    }

    // Processar escolha de plano
    if (userState[user]?.etapa === 'selecionar_plano') {
        if (['1', '2'].includes(message)) {
            const planoEscolhido = message === '1' ? 'MENSAL' : 'ANUAL';
            
            try {
                const resultado = await iniciarAssinatura(user, planoEscolhido);
                
                if (resultado.sucesso) {
                    await client.sendMessage(user, 
                        `🔗 *Link para assinatura gerado com sucesso!*\n\n` +
                        `Para concluir sua assinatura, acesse o link abaixo:\n${resultado.link}\n\n` +
                        `Após o pagamento, seu plano será ativado automaticamente.`
                    );
                } else {
                    await client.sendMessage(user, 
                        `❌ *Não foi possível gerar o link de pagamento*\n\n` +
                        `${resultado.mensagem}\n\n` +
                        `Por favor, tente novamente mais tarde ou entre em contato com o suporte.`
                    );
                }
            } catch (error) {
                console.error('Erro ao processar escolha de plano:', error);
                await client.sendMessage(user, 'Ocorreu um erro ao processar sua escolha. Por favor, tente novamente mais tarde.');
            }
            
            delete userState[user];
            return;
        } else if (message.toLowerCase() === 'cancelar') {
            delete userState[user];
            await client.sendMessage(user, 'Operação cancelada.');
            return;
        } else {
            await client.sendMessage(user, 'Opção inválida. Digite 1 para o Plano Mensal, 2 para o Plano Anual ou "cancelar" para cancelar a operação.');
            return;
        }
    }

    // Cancelar assinatura
    if (message.toLowerCase() === 'cancelar assinatura') {
        userState[user] = { etapa: 'confirmar_cancelamento' };
        await client.sendMessage(user, 
            `⚠️ *Tem certeza que deseja cancelar sua assinatura?*\n\n` +
            `Ao cancelar, você continuará com acesso até o final do período já pago, mas não será renovada automaticamente.\n\n` +
            `Digite "confirmar" para prosseguir com o cancelamento ou "voltar" para desistir.`
        );
        return;
    }

    if (userState[user]?.etapa === 'confirmar_cancelamento') {
        if (message.toLowerCase() === 'confirmar') {
            try {
                const resultado = await cancelarAssinatura(user);
                
                if (resultado.sucesso) {
                    await client.sendMessage(user, 
                        `✅ *Assinatura cancelada com sucesso*\n\n` +
                        `Seu acesso permanecerá ativo até o final do período já pago.\n\n` +
                        `Esperamos que volte em breve!`
                    );
                } else {
                    await client.sendMessage(user, 
                        `❌ *Não foi possível cancelar a assinatura*\n\n` +
                        `${resultado.mensagem}\n\n` +
                        `Por favor, tente novamente mais tarde ou entre em contato com o suporte.`
                    );
                }
            } catch (error) {
                console.error('Erro ao cancelar assinatura:', error);
                await client.sendMessage(user, 'Ocorreu um erro ao processar o cancelamento. Por favor, tente novamente mais tarde.');
            }
            
            delete userState[user];
            return;
        } else if (message.toLowerCase() === 'voltar') {
            delete userState[user];
            await client.sendMessage(user, 'Operação cancelada. Sua assinatura continua ativa.');
            return;
        } else {
            await client.sendMessage(user, 'Opção inválida. Digite "confirmar" para cancelar sua assinatura ou "voltar" para desistir.');
            return;
        }
    }

    // Incluir no manipulador principal de mensagens para processar os tutoriais
    client.on('message', async msg => {
        // Código existente...
        
        // Processamento dos tutoriais interativos
        if (userState[user]?.etapa === 'tutorial_entrada' && userState[user]?.aguardandoComando !== true) {
            await processarTutorialEntrada(client, user, message);
            return;
        }
        
        if (userState[user]?.etapa === 'tutorial_saida' && userState[user]?.aguardandoComando !== true) {
            await processarTutorialSaida(client, user, message);
            return;
        }
        
        if (userState[user]?.etapa === 'tutorial_relatorio' && userState[user]?.aguardandoComando !== true) {
            // Implementar processamento do tutorial de relatório
            // ...
            return;
        }
        
        if (userState[user]?.etapa === 'tutorial_categoria' && userState[user]?.aguardandoComando !== true) {
            // Implementar processamento do tutorial de categoria
            // ...
            return;
        }
        
        // Após primeira resposta em qualquer tutorial, desativar o flag aguardandoComando
        if (userState[user]?.aguardandoComando) {
            userState[user].aguardandoComando = false;
        }
        
        // Tratamento para escolha após finalização do tutorial
        if (userState[user]?.etapa === 'tutorial_finalizado' && ['1', '2', '3'].includes(message)) {
            switch (message) {
                case '1': // Tentar outro tutorial
                    userState[user] = { etapa: 'menu_tutoriais' };
                    await client.sendMessage(user, 'Tutoriais Interativos 🎓\n\n' +
                        'Aprenda na prática como usar o sistema:\n\n' +
                        '1 - Como registrar uma entrada\n' +
                        '2 - Como registrar uma saída\n' +
                        '3 - Como gerar um relatório\n' +
                        '4 - Como criar uma nova categoria\n\n' +
                        'Escolha uma opção para iniciar o tutorial:');
                    break;
                    
                case '2': // Voltar ao menu de ajuda
                    userState[user] = { etapa: 'menu_ajuda' };
                    await client.sendMessage(user, 'Menu de Ajuda:\n1 - Guia Rápido\n2 - Gestão Financeira\n3 - Consultas e Saldo\n4 - Relatórios e Análises\n5 - Personalização\n6 - Dicas Financeiras\n7 - FAQ\n8 - Comandos de Voz\n9 - Tutoriais Interativos');
                    break;
                    
                case '3': // Voltar ao menu principal
                    userState[user] = { etapa: 'menu' };
                    await client.sendMessage(user, 'Menu Principal:\n1 - Entradas\n2 - Saídas\n3 - Ver Saldo\n4 - Carteiras\n5 - Categorias\n6 - Relatórios\n7 - Manutenções\n8 - Ajuda\n9 - Consultoria');
                    break;
            }
            return;
        }
    })
});

client.initialize();
